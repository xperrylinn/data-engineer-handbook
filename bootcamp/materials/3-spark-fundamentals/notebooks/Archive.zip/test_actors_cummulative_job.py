#!/usr/bin/env python
# coding: utf-8
from chispa.dataframe_comparer import *
from collections import namedtuple
ActorFilm = namedtuple("ActorFilm", "actor" "actor_id film year votes rating filmid")
ActosCummulative = namedtuple("ActosCummulative", "actor quality_class is_active")


def do_actors_cummulative_job(spark: SparkSession):
    # Disable automatic broadcast join and enable bucketing options
    spark.conf.set('spark.sql.sources.v2.bucketing.enabled', 'true')
    spark.conf.set('spark.sql.iceberg.planning.preserve-data-grouping', 'true')
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")

    # Define schema for input CSV
    actor_films_schema = StructType([
        StructField("actor", StringType(), True),
        StructField("actorid", StringType(), True),
        StructField("film", StringType(), True),
        StructField("year", IntegerType(), True),
        StructField("votes", IntegerType(), True),
        StructField("rating", DoubleType(), True),
        StructField("filmid", StringType(), True)
    ])

    # Read and write actor_films.csv to Iceberg table
    actor_films_df = spark.read.option("header", "true") \
        .schema(actor_films_schema) \
        .csv("/home/iceberg/data/actor_films.csv")

    actor_films_df.writeTo("bootcamp.actor_films") \
        .using("iceberg") \
        .option("overwrite-mode", "static") \
        .tableProperty("write.format.default", "parquet") \
        .overwritePartitions()

    af = actor_films_df.alias("af")

    # Create list of years 1970–2021
    years = [(y,) for y in range(1970, 2022)]
    years_df = spark.createDataFrame(years, ["year"])
    y = years_df.alias("y")

    # First year per actor
    first_actor_year_df = actor_films_df.groupBy("actor").agg(min("year").alias("first_year"))
    fay = first_actor_year_df.alias("fay")

    # Join to get all valid (actor, year) pairs
    actors_and_years_df = fay.join(broadcast(y), col("fay.first_year") <= col("y.year")) \
        .select("fay.actor", "y.year")
    aay = actors_and_years_df.alias("aay")

    # Join (actor, year) with films up to that year
    windowed_df = aay.join(af, on=col("aay.actor") == col("af.actor"), how="left") \
        .filter(col("aay.year") >= col("af.year")) \
        .groupBy("aay.actor", "aay.year") \
        .agg(collect_list(
            struct("af.film", "af.votes", "af.rating", "af.filmid", "af.year")
        ).alias("films"))
    w = windowed_df.alias("w")

    # Derive final actor-year dataset
    actors_ready_df = w.select(
        w.actor,
        w.year,
        when(col("w.films").getItem(0).rating > 8, "star")
        .when((col("w.films").getItem(0).rating > 7) & (col("w.films").getItem(0).rating <= 8), "good")
        .when((col("w.films").getItem(0).rating > 6) & (col("w.films").getItem(0).rating <= 7), "average")
        .otherwise("bad").alias("quality_class"),
        when(col("w.films").getItem(0).year == w.year, True).otherwise(False).alias("is_active"),
        w.films
    ).orderBy("w.actor", "w.year")

    # Write output to Iceberg table
    actors_ready_df.writeTo("bootcamp.actors") \
        .using("iceberg") \
        .option("overwrite-mode", "static") \
        .tableProperty("write.format.default", "parquet") \
        .overwritePartitions()

    return actors_ready_df


def test_scd_generation(spark):
    source_data = [
        ActorFilm("50 Cent", "nm1265067", "Get Rich or Die Tryin'", 2025, 44370, 5.4, "tt0430308"),
        ActorFilm("50 Cent", "nm1265067", "Home of the Brave", 2025, 10500, 5.6, "tt0763840"),
        ActorFilm("50 Cent", "nm1265067", "Vengeance", 2025, 133, 3.5	, "tt0485920"),
    ]
    source_df = spark.createDataFrame(source_data)

    actual_df = do_actors_cummulative_job(spark, actor_films_df)
    expected_data = [
        ActorsCumulative(
            actor="50 Cent",
            year=2005,
            quality_class="bad",
            is_active=True,
            films=[
                Row(film="Get Rich or Die Tryin'", votes=44370, rating=5.4, filmid='tt0430308', year=2005)
            ]
        ),
        ActorsCumulative(
            actor="50 Cent",
            year=2006,
            quality_class="bad",
            is_active=True,
            films=[
                Row(film='Home of the Brave', votes=10500, rating=5.6, filmid='tt0763840', year=2006),
                Row(film='Vengeance', votes=133, rating=3.5, filmid='tt0485920', year=2006),
                Row(film="Get Rich or Die Tryin'", votes=44370, rating=5.4, filmid='tt0430308', year=2005)
            ]
        )
    ]
    expected_df = spark.createDataFrame(expected_data)
    assert_df_equality(actual_df, expected_df)


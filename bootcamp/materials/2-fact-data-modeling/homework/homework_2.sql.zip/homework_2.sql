WITH deduped_game_details AS (
	SELECT
		game_id,
		team_id,
		player_id,
		ROW_NUMBER() OVER (PARTITION BY game_id, team_id, player_id) AS row_numb
	FROM game_details
)
SELECT
	*
FROM deduped_game_details
WHERE row_numb = 1;
